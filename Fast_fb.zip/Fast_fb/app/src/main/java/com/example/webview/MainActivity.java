package com.example.webview;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {
private WebView wbView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading Data");
        progressDialog.setCancelable(false);

        wbView = findViewById(R.id.wbView);

        wbView.setVerticalScrollBarEnabled(true);
        wbView.requestFocus();
        wbView.getSettings().setDefaultTextEncodingName("utf-8");
        wbView.getSettings().setJavaScriptEnabled(true);
        wbView.loadUrl("https://touch.facebook.com/");

        wbView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });

        wbView.setWebChromeClient(new WebChromeClient(){
            @Override
            public void onProgressChanged(WebView view, int progress) {
                if(progress < 100)
                {
                    progressDialog.show();
                }
                if(progress == 100)
                {
                    progressDialog.dismiss();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        if(wbView != null && wbView.canGoBack())
        {
            wbView.goBack();
        }
        else
        {
            super.onBackPressed();
        }
    }
}
